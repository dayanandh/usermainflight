package com.org.user.services;

import java.math.BigInteger;

import org.springframework.http.ResponseEntity;

import com.org.user.models.Users;



public interface UserService {

	public ResponseEntity<?> createUser(Users newUser);

	public Users updateUser(Users newUser);

	public String deleteUser(BigInteger UserId);

	public Iterable<Users> displayAllUser();

	public ResponseEntity<?> findUserById(BigInteger userId);
	
	public ResponseEntity<Users> findUser(String userName ,String password );

	public ResponseEntity<Users> getRole(String username);
}