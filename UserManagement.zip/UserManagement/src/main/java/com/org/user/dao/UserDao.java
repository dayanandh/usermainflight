package com.org.user.dao;
import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;

import com.org.user.models.Users;


public interface UserDao extends CrudRepository<Users, BigInteger>{

}