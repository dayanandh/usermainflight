package com.org.user.dao;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.org.user.models.Users;

@Repository
public  class UserDaoCustImpl implements UserDaoCustom {

	@Autowired
	EntityManager entityManager;
	
	@Override
	public Users customFind(String userName, String password) {
		
		String sql = "select user from Users user where user.userName = :one and user.userPassword=:two";
		javax.persistence.Query query = (javax.persistence.Query) entityManager.createQuery(sql);
		query.setParameter("one", userName);
		query.setParameter("two", password);
		List<Users> userList =  query.getResultList();
		if(userList != null && userList.size() > 0) {
			return userList.get(0);
		}else {
			return null;
		}
		
	}

	@Override
	public ResponseEntity<Users> getRole(String username) {
		String sql = "select user from Users user where user.userName = :one";
		javax.persistence.Query query = (javax.persistence.Query) entityManager.createQuery(sql);
		query.setParameter("one", username);
		List<Users> userList =  query.getResultList();
		if(userList != null && userList.size() > 0) {
			System.out.println(userList.get(0)+"#####"+userList.get(0).getUserRole());
			return new ResponseEntity<Users>(userList.get(0), HttpStatus.OK);
		}else {
			return null;
		}
	}

	

}
