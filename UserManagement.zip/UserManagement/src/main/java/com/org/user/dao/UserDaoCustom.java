package com.org.user.dao;

import org.springframework.http.ResponseEntity;

import com.org.user.models.Users;

public interface UserDaoCustom {
	
	Users customFind(String userName,String password);

	ResponseEntity<Users> getRole(String username);

}
